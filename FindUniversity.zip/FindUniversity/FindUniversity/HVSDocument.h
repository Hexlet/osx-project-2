//
//  HVSDocument.h
//  FindUniversity
//
//  Created by VladIslav Khazov on 03.12.12.
//  Copyright (c) 2012 VladIslav Khazov. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HVSDocument : NSDocument

@end
