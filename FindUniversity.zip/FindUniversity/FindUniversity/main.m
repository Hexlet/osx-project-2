//
//  main.m
//  FindUniversity
//
//  Created by VladIslav Khazov on 03.12.12.
//  Copyright (c) 2012 VladIslav Khazov. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
